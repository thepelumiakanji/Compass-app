"use server"

import { db } from "@/lib/db"
import { documents, chunks, artifacts } from "@/lib/db/schema"
import { and, desc, eq } from "drizzle-orm"
import { revalidatePath } from "next/cache"
import { put } from "@vercel/blob"
import { getUserId } from "@/lib/session"
import { newId } from "@/lib/ai"
import { indexDocument } from "@/lib/rag"
import { extractFromFile, extractFromImage } from "@/lib/extract"

export async function getDocuments() {
  const userId = await getUserId()
  return db
    .select({
      id: documents.id,
      title: documents.title,
      subject: documents.subject,
      sourceType: documents.sourceType,
      status: documents.status,
      createdAt: documents.createdAt,
    })
    .from(documents)
    .where(eq(documents.userId, userId))
    .orderBy(desc(documents.createdAt))
}

export async function getDocument(id: string) {
  const userId = await getUserId()
  const [doc] = await db
    .select()
    .from(documents)
    .where(and(eq(documents.id, id), eq(documents.userId, userId)))
    .limit(1)
  if (!doc) return null
  const arts = await db
    .select()
    .from(artifacts)
    .where(and(eq(artifacts.documentId, id), eq(artifacts.userId, userId)))
    .orderBy(desc(artifacts.createdAt))
  return { ...doc, artifacts: arts }
}

async function persist(
  userId: string,
  data: {
    title: string
    subject?: string
    sourceType: string
    content: string
    fileUrl?: string
    fileType?: string
  },
) {
  const id = newId("doc")
  await db.insert(documents).values({
    id,
    userId,
    title: data.title,
    subject: data.subject || null,
    sourceType: data.sourceType,
    fileUrl: data.fileUrl || null,
    fileType: data.fileType || null,
    content: data.content,
    status: "ready",
  })
  if (data.content.trim()) {
    await indexDocument(userId, id, data.content)
  }
  revalidatePath("/library")
  revalidatePath("/dashboard")
  return id
}

export async function createTextDocument(input: {
  title: string
  subject?: string
  content: string
}) {
  const userId = await getUserId()
  if (!input.content.trim()) throw new Error("Content is required")
  return persist(userId, {
    title: input.title || "Untitled note",
    subject: input.subject,
    sourceType: "text",
    content: input.content,
  })
}

export async function createDocumentFromUpload(formData: FormData) {
  const userId = await getUserId()
  const file = formData.get("file") as File | null
  const title = (formData.get("title") as string) || ""
  const subject = (formData.get("subject") as string) || ""
  if (!file) throw new Error("No file provided")

  const bytes = Buffer.from(await file.arrayBuffer())
  const isImage = file.type.startsWith("image/")

  // Store the original file in Blob (private).
  const blob = await put(`compass/${userId}/${newId("f")}-${file.name}`, bytes, {
    access: "public",
    contentType: file.type,
  })

  let content = ""
  if (isImage) {
    const dataUrl = `data:${file.type};base64,${bytes.toString("base64")}`
    content = await extractFromImage(dataUrl)
  } else {
    content = await extractFromFile(bytes, file.type, file.name)
  }

  return persist(userId, {
    title: title || file.name.replace(/\.[^.]+$/, ""),
    subject,
    sourceType: isImage ? "image" : "file",
    content,
    fileUrl: blob.url,
    fileType: file.type,
  })
}

export async function deleteDocument(id: string) {
  const userId = await getUserId()
  await db
    .delete(chunks)
    .where(and(eq(chunks.documentId, id), eq(chunks.userId, userId)))
  await db
    .delete(artifacts)
    .where(and(eq(artifacts.documentId, id), eq(artifacts.userId, userId)))
  await db
    .delete(documents)
    .where(and(eq(documents.id, id), eq(documents.userId, userId)))
  revalidatePath("/library")
  revalidatePath("/dashboard")
}
