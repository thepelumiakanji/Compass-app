"use server"

import { db } from "@/lib/db"
import { plans, planTasks } from "@/lib/db/schema"
import { and, asc, desc, eq } from "drizzle-orm"
import { revalidatePath } from "next/cache"
import { generateObject } from "ai"
import { z } from "zod"
import { getUserId } from "@/lib/session"
import { MODELS, newId } from "@/lib/ai"

export async function getPlans() {
  const userId = await getUserId()
  return db
    .select()
    .from(plans)
    .where(eq(plans.userId, userId))
    .orderBy(desc(plans.createdAt))
}

export async function getPlan(id: string) {
  const userId = await getUserId()
  const [plan] = await db
    .select()
    .from(plans)
    .where(and(eq(plans.id, id), eq(plans.userId, userId)))
    .limit(1)
  if (!plan) return null
  const tasks = await db
    .select()
    .from(planTasks)
    .where(and(eq(planTasks.planId, id), eq(planTasks.userId, userId)))
    .orderBy(asc(planTasks.dayIndex), asc(planTasks.createdAt))
  return { ...plan, tasks }
}

const planSchema = z.object({
  title: z.string(),
  days: z.array(
    z.object({
      dateLabel: z
        .string()
        .describe("e.g. 'Day 1' or a weekday like 'Monday'"),
      tasks: z.array(
        z.object({
          title: z.string(),
          description: z.string(),
          technique: z
            .string()
            .describe(
              "Study technique, e.g. Active Recall, Spaced Repetition, Feynman, Pomodoro, Practice Test",
            ),
          durationMinutes: z.number().int().positive(),
        }),
      ),
    }),
  ),
})

export async function generatePlan(input: {
  subjects: string
  struggles: string
  examDate?: string
  hoursPerDay: number
}) {
  const userId = await getUserId()

  const daysUntil = input.examDate
    ? Math.max(
        1,
        Math.ceil(
          (new Date(input.examDate).getTime() - Date.now()) / 86400000,
        ),
      )
    : 7
  const horizon = Math.min(daysUntil, 21)

  const { object } = await generateObject({
    model: MODELS.generate,
    schema: planSchema,
    system:
      "You are an expert study coach who designs evidence-based revision schedules using active recall, spaced repetition, interleaving, and the Feynman technique. Distribute difficult topics earlier and build in review + practice-test days.",
    prompt: `Create a ${horizon}-day study plan.
Subjects/topics: ${input.subjects}
Where the student struggles: ${input.struggles || "not specified"}
Available study time per day: ${input.hoursPerDay} hours
${input.examDate ? `Exam/deadline date: ${input.examDate} (${daysUntil} days away)` : "No fixed deadline; optimize for steady progress."}

Keep each day's total within the available time. Prioritize the struggle areas with proven techniques.`,
  })

  const planId = newId("pln")
  await db.insert(plans).values({
    id: planId,
    userId,
    title: object.title || "Study plan",
    goal: input.subjects,
    examDate: input.examDate ? new Date(input.examDate) : null,
    hoursPerDay: input.hoursPerDay,
    struggles: input.struggles || null,
  })

  const taskRows = object.days.flatMap((day, dayIndex) =>
    day.tasks.map((t) => ({
      id: newId("ptk"),
      userId,
      planId,
      dayIndex,
      dateLabel: day.dateLabel,
      title: t.title,
      description: t.description,
      technique: t.technique,
      durationMinutes: t.durationMinutes,
      done: false,
    })),
  )
  if (taskRows.length) await db.insert(planTasks).values(taskRows)

  revalidatePath("/planner")
  return planId
}

export async function toggleTask(taskId: string, done: boolean) {
  const userId = await getUserId()
  await db
    .update(planTasks)
    .set({ done })
    .where(and(eq(planTasks.id, taskId), eq(planTasks.userId, userId)))
  revalidatePath("/planner")
}

export async function deletePlan(id: string) {
  const userId = await getUserId()
  await db
    .delete(planTasks)
    .where(and(eq(planTasks.planId, id), eq(planTasks.userId, userId)))
  await db.delete(plans).where(and(eq(plans.id, id), eq(plans.userId, userId)))
  revalidatePath("/planner")
}
