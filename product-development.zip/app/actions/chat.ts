"use server"

import { db } from "@/lib/db"
import { chats, messages } from "@/lib/db/schema"
import { and, asc, desc, eq } from "drizzle-orm"
import { revalidatePath } from "next/cache"
import { getUserId } from "@/lib/session"
import { newId } from "@/lib/ai"

export async function getChats() {
  const userId = await getUserId()
  return db
    .select()
    .from(chats)
    .where(eq(chats.userId, userId))
    .orderBy(desc(chats.createdAt))
}

export async function getMessages(chatId: string) {
  const userId = await getUserId()
  const [chat] = await db
    .select()
    .from(chats)
    .where(and(eq(chats.id, chatId), eq(chats.userId, userId)))
    .limit(1)
  if (!chat) return null
  const msgs = await db
    .select()
    .from(messages)
    .where(and(eq(messages.chatId, chatId), eq(messages.userId, userId)))
    .orderBy(asc(messages.createdAt))
  return { chat, messages: msgs }
}

export async function createChat(title: string) {
  const userId = await getUserId()
  const id = newId("cht")
  await db.insert(chats).values({ id, userId, title: title.slice(0, 80) || "New chat" })
  revalidatePath("/buddy")
  return id
}

export async function deleteChat(id: string) {
  const userId = await getUserId()
  await db
    .delete(messages)
    .where(and(eq(messages.chatId, id), eq(messages.userId, userId)))
  await db.delete(chats).where(and(eq(chats.id, id), eq(chats.userId, userId)))
  revalidatePath("/buddy")
}
