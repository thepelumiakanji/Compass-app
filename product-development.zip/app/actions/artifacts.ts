"use server"

import { db } from "@/lib/db"
import { documents, artifacts } from "@/lib/db/schema"
import { and, eq } from "drizzle-orm"
import { revalidatePath } from "next/cache"
import { generateObject } from "ai"
import { z } from "zod"
import { getUserId } from "@/lib/session"
import { MODELS, newId } from "@/lib/ai"

export type ArtifactKind =
  | "summary"
  | "flashcards"
  | "quiz"
  | "feynman"
  | "cornell"
  | "breakdown"

const schemas = {
  summary: z.object({
    title: z.string(),
    tldr: z.string().describe("2-3 sentence high-level summary"),
    keyPoints: z.array(z.string()).describe("6-10 key takeaways"),
    sections: z.array(
      z.object({ heading: z.string(), points: z.array(z.string()) }),
    ),
  }),
  flashcards: z.object({
    title: z.string(),
    cards: z
      .array(z.object({ front: z.string(), back: z.string() }))
      .describe("10-16 active-recall flashcards"),
  }),
  quiz: z.object({
    title: z.string(),
    questions: z.array(
      z.object({
        question: z.string(),
        options: z.array(z.string()).length(4),
        answerIndex: z.number().int().min(0).max(3),
        explanation: z.string(),
      }),
    ),
  }),
  feynman: z.object({
    title: z.string(),
    simpleExplanation: z
      .string()
      .describe("Explain the topic as if to a curious 12-year-old"),
    analogies: z.array(z.string()),
    gaps: z
      .array(z.string())
      .describe("Concepts that are commonly misunderstood or need review"),
  }),
  cornell: z.object({
    title: z.string(),
    cues: z.array(z.string()).describe("Cue-column questions / keywords"),
    notes: z.array(z.string()).describe("Main note-taking column points"),
    summary: z.string(),
  }),
  breakdown: z.object({
    title: z.string(),
    overview: z.string(),
    outline: z.array(
      z.object({ heading: z.string(), detail: z.string() }),
    ),
    keyConcepts: z.array(
      z.object({ term: z.string(), definition: z.string() }),
    ),
    faq: z.array(z.object({ question: z.string(), answer: z.string() })),
    studyQuestions: z.array(z.string()),
  }),
} as const

const prompts: Record<ArtifactKind, string> = {
  summary: "Create concise, well-structured study notes summarizing this material.",
  flashcards:
    "Create active-recall flashcards. Each front is a question or prompt; each back is a crisp answer.",
  quiz: "Create a multiple-choice quiz to test understanding. Vary difficulty. Provide clear explanations.",
  feynman:
    "Apply the Feynman technique: explain this material in the simplest possible terms, using analogies, and surface knowledge gaps.",
  cornell:
    "Convert this material into Cornell notes: cue questions/keywords, detailed notes, and a summary.",
  breakdown:
    "Produce a NotebookLM-style breakdown: an overview, a structured outline, key concepts with definitions, an FAQ, and study questions.",
}

export async function generateArtifact(documentId: string, kind: ArtifactKind) {
  const userId = await getUserId()
  const [doc] = await db
    .select()
    .from(documents)
    .where(and(eq(documents.id, documentId), eq(documents.userId, userId)))
    .limit(1)
  if (!doc) throw new Error("Document not found")

  const source = doc.content.slice(0, 24000)
  const { object } = await generateObject({
    model: MODELS.generate,
    schema: schemas[kind],
    system:
      "You are an expert learning scientist and study coach. Base everything strictly on the provided material. Be accurate, clear, and pedagogically effective.",
    prompt: `${prompts[kind]}\n\nMATERIAL TITLE: ${doc.title}\n\nMATERIAL:\n"""\n${source}\n"""`,
  })

  const id = newId("art")
  const title = (object as { title?: string }).title || `${kind} — ${doc.title}`
  await db.insert(artifacts).values({
    id,
    userId,
    documentId,
    kind,
    title,
    content: object,
  })
  revalidatePath(`/library/${documentId}`)
  return { id, kind, title, content: object }
}

export async function deleteArtifact(id: string, documentId: string) {
  const userId = await getUserId()
  await db
    .delete(artifacts)
    .where(and(eq(artifacts.id, id), eq(artifacts.userId, userId)))
  revalidatePath(`/library/${documentId}`)
}

export async function getRecentArtifacts(limit = 6) {
  const userId = await getUserId()
  return db
    .select({
      id: artifacts.id,
      kind: artifacts.kind,
      title: artifacts.title,
      documentId: artifacts.documentId,
      createdAt: artifacts.createdAt,
    })
    .from(artifacts)
    .where(eq(artifacts.userId, userId))
    .orderBy(artifacts.createdAt)
    .limit(limit)
}
