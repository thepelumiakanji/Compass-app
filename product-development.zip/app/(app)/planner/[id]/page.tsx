import { notFound } from "next/navigation"
import Link from "next/link"
import { getPlan } from "@/app/actions/planner"
import { PageHeader } from "@/components/page-header"
import { PlanBoard } from "@/components/plan-board"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ChevronLeft } from "lucide-react"

export default async function PlanPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const plan = await getPlan(id)
  if (!plan) notFound()

  return (
    <div>
      <div className="mb-2">
        <Button asChild variant="ghost" size="sm" className="-ml-2 text-muted-foreground">
          <Link href="/planner">
            <ChevronLeft className="mr-1 h-4 w-4" />
            Planner
          </Link>
        </Button>
      </div>

      <PageHeader title={plan.title} description={plan.goal ?? undefined}>
        {plan.examDate && (
          <Badge variant="secondary">
            Exam {new Date(plan.examDate).toLocaleDateString()}
          </Badge>
        )}
        <Badge variant="outline">{plan.hoursPerDay}h/day</Badge>
      </PageHeader>

      <PlanBoard planId={plan.id} tasks={plan.tasks} />
    </div>
  )
}
