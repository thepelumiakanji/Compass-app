import Link from "next/link"
import { getPlans } from "@/app/actions/planner"
import { PageHeader } from "@/components/page-header"
import { PlanGenerator } from "@/components/plan-generator"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CalendarDays, ChevronRight, Target } from "lucide-react"

export default async function PlannerPage() {
  const plans = await getPlans()

  return (
    <div>
      <PageHeader
        title="Study planner"
        description="Personalized, evidence-based revision schedules built around your deadlines."
      >
        <PlanGenerator />
      </PageHeader>

      {plans.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border/70 p-14 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
            <CalendarDays className="h-5 w-5" />
          </span>
          <h3 className="mt-4 text-base font-semibold">No study plans yet</h3>
          <p className="mt-1 max-w-sm text-sm text-muted-foreground text-pretty">
            Tell Compass what you&apos;re studying and when your exam is — it&apos;ll
            map out exactly what to do each day.
          </p>
          <div className="mt-5">
            <PlanGenerator />
          </div>
        </div>
      ) : (
        <div className="grid gap-3">
          {plans.map((plan) => (
            <Link key={plan.id} href={`/planner/${plan.id}`} className="group">
              <Card className="border-border/70 transition-colors group-hover:border-primary/50">
                <CardContent className="flex items-center gap-4 p-5">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Target className="h-5 w-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate font-medium">{plan.title}</h3>
                    <p className="mt-0.5 truncate text-sm text-muted-foreground">
                      {plan.goal}
                    </p>
                  </div>
                  <div className="hidden items-center gap-2 sm:flex">
                    {plan.examDate && (
                      <Badge variant="secondary">
                        Exam {new Date(plan.examDate).toLocaleDateString()}
                      </Badge>
                    )}
                    <Badge variant="outline">{plan.hoursPerDay}h/day</Badge>
                  </div>
                  <ChevronRight className="h-5 w-5 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
