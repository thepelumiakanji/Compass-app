import Link from "next/link"
import { getSessionUser } from "@/lib/session"
import { getDocuments } from "@/app/actions/documents"
import { getPlans } from "@/app/actions/planner"
import { getChats } from "@/app/actions/chat"
import { getRecentArtifacts } from "@/app/actions/artifacts"
import { PageHeader } from "@/components/page-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ARTIFACT_META } from "@/components/artifact-meta"
import {
  Library,
  CalendarDays,
  MessageCircle,
  ArrowRight,
  FileText,
  Sparkles,
} from "lucide-react"

export default async function DashboardPage() {
  const [user, documents, plans, chats, artifacts] = await Promise.all([
    getSessionUser(),
    getDocuments(),
    getPlans(),
    getChats(),
    getRecentArtifacts(5),
  ])

  const firstName = (user?.name || "there").split(" ")[0]
  const hour = new Date().getHours()
  const greeting =
    hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening"

  const stats = [
    { label: "Sources", value: documents.length, icon: FileText },
    { label: "Study sets", value: artifacts.length, icon: Sparkles },
    { label: "Plans", value: plans.length, icon: CalendarDays },
    { label: "Conversations", value: chats.length, icon: MessageCircle },
  ]

  const quickActions = [
    {
      href: "/library",
      title: "Add study material",
      description: "Upload notes, PDFs, or a photo and turn them into study sets.",
      icon: Library,
    },
    {
      href: "/planner",
      title: "Build a study plan",
      description: "Get a science-backed revision schedule around your exam.",
      icon: CalendarDays,
    },
    {
      href: "/buddy",
      title: "Ask your study buddy",
      description: "Research any topic with an AI that cites its sources.",
      icon: MessageCircle,
    },
  ]

  return (
    <>
      <PageHeader
        title={`${greeting}, ${firstName}`}
        description="Here's your learning at a glance. Pick up where you left off or start something new."
      />

      <div className="space-y-8 px-6 py-6 md:px-8">
        <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {stats.map((s) => {
            const Icon = s.icon
            return (
              <Card key={s.label} className="border-border/70">
                <CardContent className="flex items-center gap-4 p-5">
                  <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-secondary-foreground">
                    <Icon className="h-5 w-5" />
                  </span>
                  <div>
                    <p className="font-heading text-2xl font-semibold leading-none">
                      {s.value}
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {s.label}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </section>

        <section>
          <h2 className="mb-3 font-heading text-lg font-semibold">
            Jump back in
          </h2>
          <div className="grid gap-3 md:grid-cols-3">
            {quickActions.map((a) => {
              const Icon = a.icon
              return (
                <Link key={a.href} href={a.href} className="group">
                  <Card className="h-full border-border/70 transition-colors group-hover:border-primary/50 group-hover:bg-card">
                    <CardHeader className="pb-2">
                      <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                        <Icon className="h-5 w-5" />
                      </span>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium">{a.title}</h3>
                        <ArrowRight className="h-4 w-4 -translate-x-1 text-muted-foreground opacity-0 transition-all group-hover:translate-x-0 group-hover:opacity-100" />
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground text-pretty">
                        {a.description}
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        </section>

        <div className="grid gap-6 lg:grid-cols-2">
          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-heading text-lg font-semibold">
                Recent sources
              </h2>
              <Button asChild variant="ghost" size="sm">
                <Link href="/library">View library</Link>
              </Button>
            </div>
            <Card className="border-border/70">
              <CardContent className="divide-y divide-border p-0">
                {documents.length === 0 ? (
                  <EmptyRow
                    label="No sources yet"
                    hint="Upload notes to get started."
                  />
                ) : (
                  documents.slice(0, 5).map((d) => (
                    <Link
                      key={d.id}
                      href={`/library/${d.id}`}
                      className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-muted/50"
                    >
                      <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                      <span className="min-w-0 flex-1 truncate text-sm font-medium">
                        {d.title}
                      </span>
                      {d.subject && (
                        <Badge variant="secondary" className="shrink-0">
                          {d.subject}
                        </Badge>
                      )}
                    </Link>
                  ))
                )}
              </CardContent>
            </Card>
          </section>

          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-heading text-lg font-semibold">
                Recent study sets
              </h2>
            </div>
            <Card className="border-border/70">
              <CardContent className="divide-y divide-border p-0">
                {artifacts.length === 0 ? (
                  <EmptyRow
                    label="No study sets yet"
                    hint="Generate summaries, flashcards, or quizzes from a source."
                  />
                ) : (
                  artifacts.map((a) => {
                    const meta = ARTIFACT_META[a.kind as keyof typeof ARTIFACT_META]
                    const Icon = meta?.icon ?? Sparkles
                    return (
                      <Link
                        key={a.id}
                        href={`/library/${a.documentId}`}
                        className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-muted/50"
                      >
                        <Icon className="h-4 w-4 shrink-0 text-primary" />
                        <span className="min-w-0 flex-1 truncate text-sm font-medium">
                          {a.title}
                        </span>
                        <Badge variant="secondary" className="shrink-0 capitalize">
                          {a.kind}
                        </Badge>
                      </Link>
                    )
                  })
                )}
              </CardContent>
            </Card>
          </section>
        </div>
      </div>
    </>
  )
}

function EmptyRow({ label, hint }: { label: string; hint: string }) {
  return (
    <div className="px-4 py-8 text-center">
      <p className="text-sm font-medium">{label}</p>
      <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
    </div>
  )
}
