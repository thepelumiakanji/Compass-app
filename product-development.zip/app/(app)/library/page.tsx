import Link from "next/link"
import { getDocuments } from "@/app/actions/documents"
import { PageHeader } from "@/components/page-header"
import { UploadDialog } from "@/components/upload-dialog"
import { DocumentCard } from "@/components/document-card"
import { Library } from "lucide-react"

export default async function LibraryPage() {
  const documents = await getDocuments()

  return (
    <>
      <PageHeader
        title="Library"
        description="Your sources — notes, documents, and photos. Open one to generate study sets."
      >
        <UploadDialog />
      </PageHeader>

      <div className="px-6 py-6 md:px-8">
        {documents.length === 0 ? (
          <div className="mx-auto flex max-w-md flex-col items-center rounded-xl border border-dashed border-border py-16 text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-secondary text-secondary-foreground">
              <Library className="h-6 w-6" />
            </span>
            <h2 className="mt-4 font-heading text-lg font-semibold">
              Your library is empty
            </h2>
            <p className="mt-1 max-w-xs text-sm text-muted-foreground text-pretty">
              Add your first source to start turning material into summaries,
              flashcards, and quizzes.
            </p>
            <div className="mt-5">
              <UploadDialog />
            </div>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {documents.map((doc) => (
              <Link key={doc.id} href={`/library/${doc.id}`}>
                <DocumentCard doc={doc} />
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  )
}
