import { notFound } from "next/navigation"
import Link from "next/link"
import { getDocument } from "@/app/actions/documents"
import { PageHeader } from "@/components/page-header"
import { ArtifactStudio } from "@/components/artifact-studio"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { ChevronLeft, FileText } from "lucide-react"

const SOURCE_LABEL: Record<string, string> = {
  text: "Note",
  file: "File",
  image: "Image",
}

export default async function DocumentPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const doc = await getDocument(id)
  if (!doc) notFound()

  return (
    <div>
      <div className="mb-2">
        <Button asChild variant="ghost" size="sm" className="-ml-2 text-muted-foreground">
          <Link href="/library">
            <ChevronLeft className="mr-1 h-4 w-4" />
            Library
          </Link>
        </Button>
      </div>

      <PageHeader
        title={doc.title}
        description={
          doc.subject
            ? `${doc.subject} · ${doc.artifacts.length} study set${doc.artifacts.length === 1 ? "" : "s"}`
            : `${doc.artifacts.length} study set${doc.artifacts.length === 1 ? "" : "s"}`
        }
      >
        <Badge variant="secondary" className="capitalize">
          {SOURCE_LABEL[doc.sourceType] ?? doc.sourceType}
        </Badge>
      </PageHeader>

      <div className="mb-8">
        <Accordion type="single" collapsible>
          <AccordionItem value="source" className="rounded-xl border border-border/70 px-4">
            <AccordionTrigger className="text-sm">
              <span className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-muted-foreground" />
                View source material
              </span>
            </AccordionTrigger>
            <AccordionContent>
              <div className="max-h-80 overflow-y-auto whitespace-pre-wrap rounded-lg bg-muted/50 p-4 text-sm leading-relaxed text-muted-foreground">
                {doc.content.slice(0, 8000) || "No extracted text available."}
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>

      <ArtifactStudio documentId={doc.id} artifacts={doc.artifacts} />
    </div>
  )
}
