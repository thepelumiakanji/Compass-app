import { convertToModelMessages, stepCountIs, streamText, type UIMessage } from "ai"
import { db } from "@/lib/db"
import { chats, messages } from "@/lib/db/schema"
import { and, eq } from "drizzle-orm"
import { getUserId } from "@/lib/session"
import { MODELS, newId } from "@/lib/ai"
import { createResearchTools, type Citation } from "@/lib/research"

export const maxDuration = 60

const SYSTEM = `You are Compass, a warm, encouraging AI study buddy.
Your job is to help students truly understand topics, not just get answers.

Guidelines:
- Break complex ideas into simple, connected steps.
- When a question relates to the student's own material, call searchNotes FIRST.
- Use searchWikipedia for definitions/background, searchWeb for current info, and searchAcademic for research-backed claims.
- Synthesize across sources; never fabricate facts or citations.
- End with a short "Check your understanding" question when it helps learning.
- Be concise but thorough. Use markdown: headings, bullet points, and **bold** for key terms.`

export async function POST(req: Request) {
  const userId = await getUserId()
  const { messages: uiMessages, chatId } = (await req.json()) as {
    messages: UIMessage[]
    chatId: string
  }

  // Verify chat ownership.
  const [chat] = await db
    .select()
    .from(chats)
    .where(and(eq(chats.id, chatId), eq(chats.userId, userId)))
    .limit(1)
  if (!chat) return new Response("Chat not found", { status: 404 })

  const citations: Citation[] = []
  const tools = createResearchTools(userId, (c) => {
    if (!citations.some((x) => x.title === c.title && x.url === c.url)) {
      citations.push(c)
    }
  })

  // Persist the latest user message.
  const lastUser = uiMessages[uiMessages.length - 1]
  if (lastUser?.role === "user") {
    const text = lastUser.parts
      .filter((p) => p.type === "text")
      .map((p) => (p as { text: string }).text)
      .join("")
    await db.insert(messages).values({
      id: newId("msg"),
      userId,
      chatId,
      role: "user",
      content: text,
    })
  }

  const result = streamText({
    model: MODELS.chat,
    system: SYSTEM,
    messages: convertToModelMessages(uiMessages),
    tools,
    stopWhen: stepCountIs(6),
    onFinish: async ({ text }) => {
      await db.insert(messages).values({
        id: newId("msg"),
        userId,
        chatId,
        role: "assistant",
        content: text,
        citations: citations.length ? citations : null,
      })
    },
  })

  return result.toUIMessageStreamResponse({
    messageMetadata: () => ({ citations }),
  })
}
