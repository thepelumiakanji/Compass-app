"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { toggleTask, deletePlan } from "@/app/actions/planner"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"
import { CheckCircle2, Circle, Clock, Trash2 } from "lucide-react"

type Task = {
  id: string
  dayIndex: number
  dateLabel: string
  title: string
  description: string | null
  technique: string | null
  durationMinutes: number | null
  done: boolean
}

export function PlanBoard({
  planId,
  tasks,
}: {
  planId: string
  tasks: Task[]
}) {
  const router = useRouter()
  const [, startTransition] = useTransition()
  const [local, setLocal] = useState<Record<string, boolean>>(
    () => Object.fromEntries(tasks.map((t) => [t.id, t.done])),
  )

  const total = tasks.length
  const completed = tasks.filter((t) => local[t.id]).length
  const pct = total ? Math.round((completed / total) * 100) : 0

  const days = Array.from(new Set(tasks.map((t) => t.dayIndex))).sort(
    (a, b) => a - b,
  )

  function handleToggle(task: Task) {
    const next = !local[task.id]
    setLocal((s) => ({ ...s, [task.id]: next }))
    startTransition(async () => {
      try {
        await toggleTask(task.id, next)
      } catch {
        setLocal((s) => ({ ...s, [task.id]: !next }))
        toast.error("Could not update that task.")
      }
    })
  }

  async function handleDeletePlan() {
    try {
      await deletePlan(planId)
      toast.success("Plan deleted.")
      router.push("/planner")
    } catch {
      toast.error("Could not delete plan.")
    }
  }

  return (
    <div>
      <Card className="mb-8 border-border/70">
        <CardContent className="flex flex-wrap items-center gap-6 p-5">
          <div className="flex-1 min-w-[200px]">
            <div className="mb-2 flex items-center justify-between text-sm">
              <span className="font-medium">Overall progress</span>
              <span className="text-muted-foreground">
                {completed}/{total} tasks
              </span>
            </div>
            <Progress value={pct} />
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-destructive"
            onClick={handleDeletePlan}
          >
            <Trash2 className="mr-1.5 h-4 w-4" />
            Delete plan
          </Button>
        </CardContent>
      </Card>

      <div className="grid gap-6">
        {days.map((dayIndex) => {
          const dayTasks = tasks.filter((t) => t.dayIndex === dayIndex)
          const label = dayTasks[0]?.dateLabel ?? `Day ${dayIndex + 1}`
          const dayMinutes = dayTasks.reduce(
            (sum, t) => sum + (t.durationMinutes ?? 0),
            0,
          )
          const dayDone = dayTasks.every((t) => local[t.id])
          return (
            <section key={dayIndex}>
              <div className="mb-3 flex items-center gap-3">
                <h2
                  className={cn(
                    "flex h-8 items-center gap-2 rounded-full px-3 text-sm font-semibold",
                    dayDone
                      ? "bg-primary/10 text-primary"
                      : "bg-muted text-foreground",
                  )}
                >
                  {dayDone && <CheckCircle2 className="h-4 w-4" />}
                  {label}
                </h2>
                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Clock className="h-3.5 w-3.5" />
                  {Math.round(dayMinutes / 60 * 10) / 10}h
                </span>
              </div>
              <div className="grid gap-2">
                {dayTasks.map((task) => {
                  const done = local[task.id]
                  return (
                    <button
                      key={task.id}
                      type="button"
                      onClick={() => handleToggle(task)}
                      className={cn(
                        "flex items-start gap-3 rounded-xl border border-border/70 bg-card p-4 text-left transition-colors hover:border-primary/40",
                        done && "opacity-70",
                      )}
                    >
                      <span className="mt-0.5 text-primary">
                        {done ? (
                          <CheckCircle2 className="h-5 w-5" />
                        ) : (
                          <Circle className="h-5 w-5 text-muted-foreground" />
                        )}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span
                          className={cn(
                            "block font-medium leading-snug",
                            done && "line-through",
                          )}
                        >
                          {task.title}
                        </span>
                        {task.description && (
                          <span className="mt-1 block text-sm text-muted-foreground text-pretty">
                            {task.description}
                          </span>
                        )}
                        <span className="mt-2 flex flex-wrap items-center gap-2">
                          {task.technique && (
                            <Badge variant="secondary" className="font-normal">
                              {task.technique}
                            </Badge>
                          )}
                          {task.durationMinutes != null && (
                            <span className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Clock className="h-3 w-3" />
                              {task.durationMinutes} min
                            </span>
                          )}
                        </span>
                      </span>
                    </button>
                  )
                })}
              </div>
            </section>
          )
        })}
      </div>
    </div>
  )
}
