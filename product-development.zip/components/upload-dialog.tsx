"use client"

import type React from "react"
import { useRef, useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import {
  createTextDocument,
  createDocumentFromUpload,
} from "@/app/actions/documents"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Upload, FileText, Loader2, Plus, ImageIcon } from "lucide-react"

export function UploadDialog({
  trigger,
}: {
  trigger?: React.ReactNode
}) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [fileName, setFileName] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  async function handleText(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    const content = String(form.get("content") || "").trim()
    if (!content) {
      toast.error("Please paste some notes first.")
      return
    }
    setLoading(true)
    try {
      const id = await createTextDocument({
        title: String(form.get("title") || "").trim() || "Untitled note",
        subject: String(form.get("subject") || "").trim() || undefined,
        content,
      })
      toast.success("Notes added and indexed.")
      setOpen(false)
      router.push(`/library/${id}`)
      router.refresh()
    } catch {
      toast.error("Something went wrong saving your notes.")
    } finally {
      setLoading(false)
    }
  }

  async function handleFile(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    const file = form.get("file") as File | null
    if (!file || file.size === 0) {
      toast.error("Please choose a file or image.")
      return
    }
    setLoading(true)
    try {
      const id = await createDocumentFromUpload(form)
      toast.success("File processed and added to your library.")
      setOpen(false)
      router.push(`/library/${id}`)
      router.refresh()
    } catch {
      toast.error("Could not process that file. Try a PDF, DOCX, image, or text.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Add material
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading">Add study material</DialogTitle>
          <DialogDescription>
            Paste notes, or upload a document or a photo of your handwriting.
            Everything is indexed so your buddy can reference it.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="text" className="mt-2">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="text" className="gap-2">
              <FileText className="h-4 w-4" />
              Paste text
            </TabsTrigger>
            <TabsTrigger value="file" className="gap-2">
              <Upload className="h-4 w-4" />
              Upload file
            </TabsTrigger>
          </TabsList>

          <TabsContent value="text">
            <form onSubmit={handleText} className="flex flex-col gap-4 pt-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-2">
                  <Label htmlFor="t-title">Title</Label>
                  <Input id="t-title" name="title" placeholder="Cell biology" />
                </div>
                <div className="flex flex-col gap-2">
                  <Label htmlFor="t-subject">Subject</Label>
                  <Input id="t-subject" name="subject" placeholder="Biology" />
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="t-content">Notes</Label>
                <Textarea
                  id="t-content"
                  name="content"
                  placeholder="Paste lecture notes, a textbook passage, or anything you want to study..."
                  className="min-h-40 resize-none"
                  required
                />
              </div>
              <Button type="submit" disabled={loading} className="gap-2">
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                Add & index
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="file">
            <form onSubmit={handleFile} className="flex flex-col gap-4 pt-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-2">
                  <Label htmlFor="f-title">Title (optional)</Label>
                  <Input id="f-title" name="title" placeholder="Auto from filename" />
                </div>
                <div className="flex flex-col gap-2">
                  <Label htmlFor="f-subject">Subject</Label>
                  <Input id="f-subject" name="subject" placeholder="History" />
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="f-file">File or photo</Label>
                <label
                  htmlFor="f-file"
                  className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border bg-muted/30 px-4 py-8 text-center transition-colors hover:bg-muted/60"
                >
                  <ImageIcon className="h-6 w-6 text-muted-foreground" />
                  <span className="text-sm font-medium">
                    {fileName ?? "Click to choose a file"}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    PDF, DOCX, TXT, or an image of notes
                  </span>
                </label>
                <input
                  ref={fileInputRef}
                  id="f-file"
                  name="file"
                  type="file"
                  accept=".pdf,.docx,.txt,.md,image/*"
                  className="sr-only"
                  onChange={(e) =>
                    setFileName(e.target.files?.[0]?.name ?? null)
                  }
                />
              </div>
              <Button type="submit" disabled={loading} className="gap-2">
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                {loading ? "Processing..." : "Upload & extract"}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
