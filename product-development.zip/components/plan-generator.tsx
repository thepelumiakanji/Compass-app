"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { generatePlan } from "@/app/actions/planner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Loader2, Plus, Sparkles } from "lucide-react"

export function PlanGenerator({
  trigger,
}: {
  trigger?: React.ReactNode
}) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [subjects, setSubjects] = useState("")
  const [struggles, setStruggles] = useState("")
  const [examDate, setExamDate] = useState("")
  const [hoursPerDay, setHoursPerDay] = useState("2")

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!subjects.trim()) {
      toast.error("Tell Compass what you're studying.")
      return
    }
    setLoading(true)
    try {
      const planId = await generatePlan({
        subjects,
        struggles,
        examDate: examDate || undefined,
        hoursPerDay: Number(hoursPerDay) || 2,
      })
      toast.success("Your study plan is ready.")
      setOpen(false)
      setSubjects("")
      setStruggles("")
      setExamDate("")
      router.push(`/planner/${planId}`)
    } catch {
      toast.error("Could not build a plan. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button>
            <Plus className="mr-1.5 h-4 w-4" />
            New plan
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Build a study plan
          </DialogTitle>
          <DialogDescription>
            Compass designs an evidence-based schedule around your goals and the
            time you have.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="subjects">What are you studying?</Label>
            <Textarea
              id="subjects"
              value={subjects}
              onChange={(e) => setSubjects(e.target.value)}
              placeholder="e.g. Organic chemistry — reaction mechanisms, stereochemistry, spectroscopy"
              rows={3}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="struggles">Where do you struggle? (optional)</Label>
            <Textarea
              id="struggles"
              value={struggles}
              onChange={(e) => setStruggles(e.target.value)}
              placeholder="e.g. I keep mixing up SN1 vs SN2 and forget NMR splitting rules"
              rows={2}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="examDate">Exam / deadline (optional)</Label>
              <Input
                id="examDate"
                type="date"
                value={examDate}
                onChange={(e) => setExamDate(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="hours">Hours per day</Label>
              <Input
                id="hours"
                type="number"
                min="1"
                max="12"
                step="0.5"
                value={hoursPerDay}
                onChange={(e) => setHoursPerDay(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                  Designing your plan…
                </>
              ) : (
                <>
                  <Sparkles className="mr-1.5 h-4 w-4" />
                  Generate plan
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
