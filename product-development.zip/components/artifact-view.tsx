"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { deleteArtifact } from "@/app/actions/artifacts"
import { ARTIFACT_META, type ArtifactKind } from "@/components/artifact-meta"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { cn } from "@/lib/utils"
import {
  Trash2,
  RotateCw,
  CheckCircle2,
  XCircle,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"

type Artifact = {
  id: string
  kind: string
  title: string
  content: unknown
  documentId: string | null
}

export function ArtifactView({ artifact }: { artifact: Artifact }) {
  const router = useRouter()
  const [deleting, setDeleting] = useState(false)
  const meta = ARTIFACT_META[artifact.kind as ArtifactKind]
  const Icon = meta?.icon

  async function handleDelete() {
    setDeleting(true)
    try {
      await deleteArtifact(artifact.id, artifact.documentId ?? "")
      toast.success("Study set removed.")
      router.refresh()
    } catch {
      toast.error("Could not delete that study set.")
      setDeleting(false)
    }
  }

  return (
    <Card className="border-border/70">
      <CardContent className="p-5">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            {Icon && (
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Icon className="h-4 w-4" />
              </span>
            )}
            <div>
              <h3 className="font-medium leading-tight text-pretty">
                {artifact.title}
              </h3>
              <p className="text-xs text-muted-foreground">
                {meta?.label ?? artifact.kind}
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleDelete}
            disabled={deleting}
            aria-label="Delete study set"
            className="text-muted-foreground hover:text-destructive"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
        <ArtifactBody kind={artifact.kind} content={artifact.content} />
      </CardContent>
    </Card>
  )
}

function ArtifactBody({ kind, content }: { kind: string; content: unknown }) {
  switch (kind) {
    case "summary":
      return <SummaryView content={content as SummaryContent} />
    case "flashcards":
      return <FlashcardsView content={content as FlashcardsContent} />
    case "quiz":
      return <QuizView content={content as QuizContent} />
    case "feynman":
      return <FeynmanView content={content as FeynmanContent} />
    case "cornell":
      return <CornellView content={content as CornellContent} />
    case "breakdown":
      return <BreakdownView content={content as BreakdownContent} />
    default:
      return null
  }
}

/* ---------------- Summary ---------------- */
type SummaryContent = {
  tldr: string
  keyPoints: string[]
  sections: { heading: string; points: string[] }[]
}
function SummaryView({ content }: { content: SummaryContent }) {
  return (
    <div className="space-y-4">
      <p className="rounded-lg bg-muted/50 p-3 text-sm leading-relaxed">
        {content.tldr}
      </p>
      <div>
        <h4 className="mb-2 text-sm font-semibold">Key points</h4>
        <ul className="space-y-1.5">
          {content.keyPoints?.map((p, i) => (
            <li key={i} className="flex gap-2 text-sm leading-relaxed">
              <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
              {p}
            </li>
          ))}
        </ul>
      </div>
      {content.sections?.map((s, i) => (
        <div key={i}>
          <h4 className="mb-1.5 text-sm font-semibold">{s.heading}</h4>
          <ul className="space-y-1 pl-4">
            {s.points?.map((p, j) => (
              <li key={j} className="list-disc text-sm leading-relaxed marker:text-muted-foreground">
                {p}
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  )
}

/* ---------------- Flashcards ---------------- */
type FlashcardsContent = { cards: { front: string; back: string }[] }
function FlashcardsView({ content }: { content: FlashcardsContent }) {
  const cards = content.cards ?? []
  const [index, setIndex] = useState(0)
  const [flipped, setFlipped] = useState(false)
  if (cards.length === 0) return null
  const card = cards[index]

  function go(delta: number) {
    setFlipped(false)
    setIndex((i) => (i + delta + cards.length) % cards.length)
  }

  return (
    <div className="space-y-3">
      <button
        type="button"
        onClick={() => setFlipped((f) => !f)}
        className="flex min-h-40 w-full flex-col items-center justify-center gap-2 rounded-xl border border-border bg-card p-6 text-center transition-colors hover:bg-muted/40"
      >
        <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {flipped ? "Answer" : "Question"}
        </span>
        <span className="text-pretty text-base leading-relaxed">
          {flipped ? card.back : card.front}
        </span>
        <span className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
          <RotateCw className="h-3 w-3" />
          Tap to flip
        </span>
      </button>
      <div className="flex items-center justify-between">
        <Button variant="outline" size="sm" onClick={() => go(-1)} className="gap-1">
          <ChevronLeft className="h-4 w-4" />
          Prev
        </Button>
        <span className="text-xs text-muted-foreground">
          {index + 1} / {cards.length}
        </span>
        <Button variant="outline" size="sm" onClick={() => go(1)} className="gap-1">
          Next
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

/* ---------------- Quiz ---------------- */
type QuizContent = {
  questions: {
    question: string
    options: string[]
    answerIndex: number
    explanation: string
  }[]
}
function QuizView({ content }: { content: QuizContent }) {
  const questions = content.questions ?? []
  const [answers, setAnswers] = useState<Record<number, number>>({})

  return (
    <div className="space-y-5">
      {questions.map((q, qi) => {
        const chosen = answers[qi]
        const answered = chosen !== undefined
        return (
          <div key={qi}>
            <p className="mb-2 text-sm font-medium leading-relaxed">
              {qi + 1}. {q.question}
            </p>
            <div className="space-y-1.5">
              {q.options.map((opt, oi) => {
                const isCorrect = oi === q.answerIndex
                const isChosen = oi === chosen
                return (
                  <button
                    key={oi}
                    type="button"
                    disabled={answered}
                    onClick={() => setAnswers((a) => ({ ...a, [qi]: oi }))}
                    className={cn(
                      "flex w-full items-center gap-2 rounded-lg border border-border px-3 py-2 text-left text-sm transition-colors",
                      !answered && "hover:bg-muted/50",
                      answered && isCorrect && "border-primary/60 bg-primary/10",
                      answered &&
                        isChosen &&
                        !isCorrect &&
                        "border-destructive/50 bg-destructive/10",
                    )}
                  >
                    <span className="flex-1">{opt}</span>
                    {answered && isCorrect && (
                      <CheckCircle2 className="h-4 w-4 shrink-0 text-primary" />
                    )}
                    {answered && isChosen && !isCorrect && (
                      <XCircle className="h-4 w-4 shrink-0 text-destructive" />
                    )}
                  </button>
                )
              })}
            </div>
            {answered && (
              <p className="mt-2 rounded-md bg-muted/50 p-2 text-xs leading-relaxed text-muted-foreground">
                {q.explanation}
              </p>
            )}
          </div>
        )
      })}
    </div>
  )
}

/* ---------------- Feynman ---------------- */
type FeynmanContent = {
  simpleExplanation: string
  analogies: string[]
  gaps: string[]
}
function FeynmanView({ content }: { content: FeynmanContent }) {
  return (
    <div className="space-y-4 text-sm leading-relaxed">
      <div>
        <h4 className="mb-1.5 font-semibold">In simple terms</h4>
        <p>{content.simpleExplanation}</p>
      </div>
      {content.analogies?.length > 0 && (
        <div>
          <h4 className="mb-1.5 font-semibold">Analogies</h4>
          <ul className="space-y-1 pl-4">
            {content.analogies.map((a, i) => (
              <li key={i} className="list-disc marker:text-muted-foreground">
                {a}
              </li>
            ))}
          </ul>
        </div>
      )}
      {content.gaps?.length > 0 && (
        <div>
          <h4 className="mb-1.5 font-semibold">Watch out for</h4>
          <ul className="space-y-1 pl-4">
            {content.gaps.map((g, i) => (
              <li key={i} className="list-disc marker:text-destructive">
                {g}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}

/* ---------------- Cornell ---------------- */
type CornellContent = { cues: string[]; notes: string[]; summary: string }
function CornellView({ content }: { content: CornellContent }) {
  return (
    <div className="space-y-3 text-sm leading-relaxed">
      <div className="grid grid-cols-3 gap-3">
        <div className="col-span-1">
          <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Cues
          </h4>
          <ul className="space-y-1.5">
            {content.cues?.map((c, i) => (
              <li key={i} className="font-medium">
                {c}
              </li>
            ))}
          </ul>
        </div>
        <div className="col-span-2 border-l border-border pl-3">
          <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Notes
          </h4>
          <ul className="space-y-1 pl-4">
            {content.notes?.map((n, i) => (
              <li key={i} className="list-disc marker:text-muted-foreground">
                {n}
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="rounded-lg bg-muted/50 p-3">
        <h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Summary
        </h4>
        <p>{content.summary}</p>
      </div>
    </div>
  )
}

/* ---------------- Breakdown ---------------- */
type BreakdownContent = {
  overview: string
  outline: { heading: string; detail: string }[]
  keyConcepts: { term: string; definition: string }[]
  faq: { question: string; answer: string }[]
  studyQuestions: string[]
}
function BreakdownView({ content }: { content: BreakdownContent }) {
  return (
    <div className="space-y-5 text-sm leading-relaxed">
      <p className="rounded-lg bg-muted/50 p-3">{content.overview}</p>

      {content.outline?.length > 0 && (
        <div>
          <h4 className="mb-2 font-semibold">Outline</h4>
          <div className="space-y-2">
            {content.outline.map((o, i) => (
              <div key={i} className="border-l-2 border-primary/40 pl-3">
                <p className="font-medium">{o.heading}</p>
                <p className="text-muted-foreground">{o.detail}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {content.keyConcepts?.length > 0 && (
        <div>
          <h4 className="mb-2 font-semibold">Key concepts</h4>
          <dl className="space-y-2">
            {content.keyConcepts.map((k, i) => (
              <div key={i}>
                <dt className="font-medium">{k.term}</dt>
                <dd className="text-muted-foreground">{k.definition}</dd>
              </div>
            ))}
          </dl>
        </div>
      )}

      {content.faq?.length > 0 && (
        <div>
          <h4 className="mb-1 font-semibold">FAQ</h4>
          <Accordion type="single" collapsible className="w-full">
            {content.faq.map((f, i) => (
              <AccordionItem key={i} value={`faq-${i}`}>
                <AccordionTrigger className="text-left text-sm">
                  {f.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {f.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      )}

      {content.studyQuestions?.length > 0 && (
        <div>
          <h4 className="mb-2 font-semibold">Study questions</h4>
          <ol className="space-y-1.5 pl-4">
            {content.studyQuestions.map((q, i) => (
              <li key={i} className="list-decimal marker:text-muted-foreground">
                {q}
              </li>
            ))}
          </ol>
        </div>
      )}
    </div>
  )
}
