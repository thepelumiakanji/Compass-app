import type React from "react"

export function PageHeader({
  title,
  description,
  children,
}: {
  title: string
  description?: string
  children?: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-4 border-b border-border bg-card/40 px-6 py-6 sm:flex-row sm:items-end sm:justify-between md:px-8">
      <div className="max-w-2xl">
        <h1 className="font-heading text-2xl font-semibold tracking-tight text-balance md:text-3xl">
          {title}
        </h1>
        {description && (
          <p className="mt-1.5 text-sm text-muted-foreground text-pretty">
            {description}
          </p>
        )}
      </div>
      {children && <div className="flex shrink-0 gap-2">{children}</div>}
    </div>
  )
}
