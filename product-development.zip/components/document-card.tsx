import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, ImageIcon, NotebookPen } from "lucide-react"

const SOURCE_ICON = {
  text: NotebookPen,
  file: FileText,
  image: ImageIcon,
} as const

export function DocumentCard({
  doc,
}: {
  doc: {
    id: string
    title: string
    subject: string | null
    sourceType: string
    createdAt: Date
  }
}) {
  const Icon =
    SOURCE_ICON[doc.sourceType as keyof typeof SOURCE_ICON] ?? FileText
  return (
    <Card className="h-full border-border/70 transition-colors hover:border-primary/50 hover:bg-card">
      <CardContent className="flex h-full flex-col gap-3 p-5">
        <div className="flex items-start justify-between gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <Icon className="h-4 w-4" />
          </span>
          {doc.subject && (
            <Badge variant="secondary" className="shrink-0">
              {doc.subject}
            </Badge>
          )}
        </div>
        <div className="flex-1">
          <h3 className="font-medium leading-snug text-pretty">{doc.title}</h3>
        </div>
        <p className="text-xs text-muted-foreground">
          {new Date(doc.createdAt).toLocaleDateString(undefined, {
            month: "short",
            day: "numeric",
            year: "numeric",
          })}
        </p>
      </CardContent>
    </Card>
  )
}
