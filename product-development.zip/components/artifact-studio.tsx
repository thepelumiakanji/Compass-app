"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { generateArtifact } from "@/app/actions/artifacts"
import { ARTIFACT_META, ARTIFACT_ORDER, type ArtifactKind } from "@/components/artifact-meta"
import { ArtifactView } from "@/components/artifact-view"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { Loader2, Sparkles } from "lucide-react"

type Artifact = {
  id: string
  kind: string
  title: string
  content: unknown
  documentId: string | null
}

export function ArtifactStudio({
  documentId,
  artifacts,
}: {
  documentId: string
  artifacts: Artifact[]
}) {
  const router = useRouter()
  const [pending, setPending] = useState<ArtifactKind | null>(null)

  async function handleGenerate(kind: ArtifactKind) {
    setPending(kind)
    try {
      await generateArtifact(documentId, kind)
      toast.success(`${ARTIFACT_META[kind].label} ready.`)
      router.refresh()
    } catch {
      toast.error("Generation failed. Please try again.")
    } finally {
      setPending(null)
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[280px_1fr]">
      <aside className="lg:sticky lg:top-6 lg:self-start">
        <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
          <Sparkles className="h-4 w-4 text-primary" />
          Generate a study set
        </div>
        <div className="mt-3 grid gap-2">
          {ARTIFACT_ORDER.map((kind) => {
            const meta = ARTIFACT_META[kind]
            const Icon = meta.icon
            const isPending = pending === kind
            return (
              <button
                key={kind}
                type="button"
                disabled={pending !== null}
                onClick={() => handleGenerate(kind)}
                className={cn(
                  "group flex items-start gap-3 rounded-xl border border-border/70 bg-card p-3 text-left transition-colors hover:border-primary/50 hover:bg-accent disabled:opacity-60",
                )}
              >
                <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  {isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Icon className="h-4 w-4" />
                  )}
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-medium leading-tight">{meta.label}</span>
                  <span className="mt-0.5 block text-xs leading-snug text-muted-foreground text-pretty">
                    {meta.blurb}
                  </span>
                </span>
              </button>
            )
          })}
        </div>
      </aside>

      <div className="min-w-0">
        {artifacts.length === 0 ? (
          <div className="flex h-full min-h-[260px] flex-col items-center justify-center rounded-2xl border border-dashed border-border/70 p-10 text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Sparkles className="h-5 w-5" />
            </span>
            <h3 className="mt-4 text-base font-semibold">No study sets yet</h3>
            <p className="mt-1 max-w-sm text-sm text-muted-foreground text-pretty">
              Pick a format on the left and Compass will turn this material into
              flashcards, quizzes, summaries, and more.
            </p>
          </div>
        ) : (
          <div className="grid gap-5">
            {artifacts.map((art) => (
              <ArtifactView key={art.id} artifact={art} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
