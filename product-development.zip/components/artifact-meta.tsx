import {
  NotebookPen,
  Layers,
  ListChecks,
  Brain,
  BookOpen,
  Wand2,
} from "lucide-react"

export type ArtifactKind =
  | "summary"
  | "flashcards"
  | "quiz"
  | "feynman"
  | "cornell"
  | "breakdown"

export const ARTIFACT_META: Record<
  ArtifactKind,
  { label: string; icon: typeof NotebookPen; blurb: string }
> = {
  summary: {
    label: "Summary",
    icon: NotebookPen,
    blurb: "Concise notes with key takeaways",
  },
  flashcards: {
    label: "Flashcards",
    icon: Layers,
    blurb: "Active-recall question / answer cards",
  },
  quiz: {
    label: "Quiz",
    icon: ListChecks,
    blurb: "Multiple-choice questions with explanations",
  },
  feynman: {
    label: "Feynman",
    icon: Brain,
    blurb: "Explain it simply and find gaps",
  },
  cornell: {
    label: "Cornell notes",
    icon: BookOpen,
    blurb: "Cues, notes, and a summary",
  },
  breakdown: {
    label: "Deep breakdown",
    icon: Wand2,
    blurb: "Outline, concepts, FAQ, and study questions",
  },
}

export const ARTIFACT_ORDER: ArtifactKind[] = [
  "summary",
  "breakdown",
  "flashcards",
  "quiz",
  "feynman",
  "cornell",
]
