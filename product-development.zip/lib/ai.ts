// Central place for AI Gateway model IDs (provider/model format).
// AI Gateway auth is zero-config in v0 previews and Vercel deployments.
export const MODELS = {
  // Fast, capable general model with tool + vision support.
  chat: "openai/gpt-4.1-mini",
  // Structured generation (summaries, flashcards, quizzes, breakdowns, plans).
  generate: "openai/gpt-4.1-mini",
  // Vision OCR for photos of handwritten / printed notes.
  vision: "openai/gpt-4.1-mini",
  // 1536-dim embeddings — matches the pgvector column in the schema.
  embedding: "openai/text-embedding-3-small",
} as const

export function newId(prefix: string) {
  return `${prefix}_${crypto.randomUUID().replace(/-/g, "").slice(0, 20)}`
}
