import "server-only"
import { tool } from "ai"
import { z } from "zod"
import { retrieve } from "@/lib/rag"

type Citation = { title: string; url?: string; source: string }

// Shared collector so the route can surface citations to the client.
export function createResearchTools(userId: string, collect: (c: Citation) => void) {
  return {
    searchNotes: tool({
      description:
        "Search the student's OWN uploaded notes and study library for relevant passages. Use this first when the question might relate to their material.",
      inputSchema: z.object({
        query: z.string().describe("What to look for in the student's notes"),
      }),
      execute: async ({ query }) => {
        const hits = await retrieve(userId, query, { limit: 6 })
        if (hits.length === 0) return "No relevant passages found in the student's notes."
        collect({ title: "Your notes & library", source: "library" })
        return hits
          .map((h, i) => `[Note ${i + 1}] ${h.content}`)
          .join("\n\n")
      },
    }),

    searchWeb: tool({
      description:
        "Search the live web for current, general information. Returns titles, snippets, and URLs.",
      inputSchema: z.object({
        query: z.string().describe("Web search query"),
      }),
      execute: async ({ query }) => {
        try {
          const res = await fetch(
            `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`,
          )
          const data = (await res.json()) as {
            AbstractText?: string
            AbstractURL?: string
            Heading?: string
            RelatedTopics?: Array<{ Text?: string; FirstURL?: string }>
          }
          const results: string[] = []
          if (data.AbstractText) {
            collect({
              title: data.Heading || query,
              url: data.AbstractURL,
              source: "web",
            })
            results.push(`${data.Heading || ""}: ${data.AbstractText} (${data.AbstractURL || ""})`)
          }
          for (const t of (data.RelatedTopics || []).slice(0, 5)) {
            if (t.Text) {
              if (t.FirstURL) collect({ title: t.Text.slice(0, 80), url: t.FirstURL, source: "web" })
              results.push(`${t.Text} (${t.FirstURL || ""})`)
            }
          }
          return results.length ? results.join("\n\n") : "No web results found."
        } catch {
          return "Web search is temporarily unavailable."
        }
      },
    }),

    searchWikipedia: tool({
      description:
        "Look up encyclopedic background on a topic from Wikipedia. Good for definitions, history, and established facts.",
      inputSchema: z.object({
        query: z.string().describe("Topic or term to look up"),
      }),
      execute: async ({ query }) => {
        try {
          const searchRes = await fetch(
            `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&srlimit=1&origin=*`,
          )
          const searchData = (await searchRes.json()) as {
            query?: { search?: Array<{ title: string }> }
          }
          const title = searchData.query?.search?.[0]?.title
          if (!title) return "No Wikipedia article found."
          const sumRes = await fetch(
            `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`,
          )
          const sum = (await sumRes.json()) as {
            extract?: string
            content_urls?: { desktop?: { page?: string } }
          }
          const url = sum.content_urls?.desktop?.page
          collect({ title: `Wikipedia: ${title}`, url, source: "wikipedia" })
          return `${title}: ${sum.extract || "No summary available."} (${url || ""})`
        } catch {
          return "Wikipedia lookup is temporarily unavailable."
        }
      },
    }),

    searchAcademic: tool({
      description:
        "Search academic literature (papers, studies) via OpenAlex. Use for scholarly / research-backed questions.",
      inputSchema: z.object({
        query: z.string().describe("Academic search query"),
      }),
      execute: async ({ query }) => {
        try {
          const res = await fetch(
            `https://api.openalex.org/works?search=${encodeURIComponent(query)}&per_page=4&sort=relevance_score:desc`,
          )
          const data = (await res.json()) as {
            results?: Array<{
              title?: string
              publication_year?: number
              doi?: string
              abstract_inverted_index?: Record<string, number[]>
              primary_location?: { landing_page_url?: string }
            }>
          }
          const works = data.results || []
          if (works.length === 0) return "No academic papers found."
          return works
            .map((w) => {
              const url = w.doi || w.primary_location?.landing_page_url
              collect({
                title: w.title || "Untitled paper",
                url: url || undefined,
                source: "academic",
              })
              return `"${w.title}" (${w.publication_year || "n.d."}) ${url || ""}`
            })
            .join("\n\n")
        } catch {
          return "Academic search is temporarily unavailable."
        }
      },
    }),
  }
}

export type { Citation }
