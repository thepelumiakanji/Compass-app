import "server-only"
import { embed, embedMany } from "ai"
import { db } from "@/lib/db"
import { chunks } from "@/lib/db/schema"
import { and, eq, sql } from "drizzle-orm"
import { MODELS, newId } from "@/lib/ai"

// Split text into overlapping chunks on paragraph / sentence boundaries.
export function chunkText(text: string, target = 900, overlap = 150): string[] {
  const clean = text.replace(/\r\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim()
  if (!clean) return []
  const paragraphs = clean.split(/\n\n+/)
  const out: string[] = []
  let buf = ""
  for (const p of paragraphs) {
    if ((buf + "\n\n" + p).length > target && buf) {
      out.push(buf.trim())
      buf = buf.slice(Math.max(0, buf.length - overlap)) + "\n\n" + p
    } else {
      buf = buf ? buf + "\n\n" + p : p
    }
  }
  if (buf.trim()) out.push(buf.trim())
  // Hard-split any oversized chunk.
  return out.flatMap((c) =>
    c.length <= target * 1.8
      ? [c]
      : (c.match(new RegExp(`[\\s\\S]{1,${target}}`, "g")) ?? [c]),
  )
}

export async function embedText(text: string) {
  const { embedding } = await embed({ model: MODELS.embedding, value: text })
  return embedding
}

// Embed + store all chunks for a document.
export async function indexDocument(
  userId: string,
  documentId: string,
  content: string,
) {
  const parts = chunkText(content)
  if (parts.length === 0) return 0
  const { embeddings } = await embedMany({
    model: MODELS.embedding,
    values: parts,
  })
  await db.insert(chunks).values(
    parts.map((content, i) => ({
      id: newId("chk"),
      userId,
      documentId,
      content,
      embedding: embeddings[i],
    })),
  )
  return parts.length
}

export type RetrievedChunk = {
  content: string
  documentId: string
  similarity: number
}

// Cosine-similarity search scoped to a single user (optionally one document).
export async function retrieve(
  userId: string,
  query: string,
  opts: { documentId?: string; limit?: number } = {},
): Promise<RetrievedChunk[]> {
  const limit = opts.limit ?? 6
  const queryEmbedding = await embedText(query)
  const vec = `[${queryEmbedding.join(",")}]`
  const similarity = sql<number>`1 - (${chunks.embedding} <=> ${vec}::vector)`
  const where = opts.documentId
    ? and(eq(chunks.userId, userId), eq(chunks.documentId, opts.documentId))
    : eq(chunks.userId, userId)
  const rows = await db
    .select({
      content: chunks.content,
      documentId: chunks.documentId,
      similarity,
    })
    .from(chunks)
    .where(where)
    .orderBy(sql`${chunks.embedding} <=> ${vec}::vector`)
    .limit(limit)
  return rows
}
