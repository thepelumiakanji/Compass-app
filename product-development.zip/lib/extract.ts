import "server-only"
import { generateText } from "ai"
import { MODELS } from "@/lib/ai"

// Extract plain text from an uploaded file buffer based on its type.
export async function extractFromFile(
  buffer: Buffer,
  fileType: string,
  fileName: string,
): Promise<string> {
  const lower = fileName.toLowerCase()

  if (fileType.includes("pdf") || lower.endsWith(".pdf")) {
    const { extractText, getDocumentProxy } = await import("unpdf")
    const pdf = await getDocumentProxy(new Uint8Array(buffer))
    const { text } = await extractText(pdf, { mergePages: true })
    return Array.isArray(text) ? text.join("\n\n") : text
  }

  if (
    fileType.includes("word") ||
    fileType.includes("officedocument") ||
    lower.endsWith(".docx")
  ) {
    const mammoth = await import("mammoth")
    const { value } = await mammoth.extractRawText({ buffer })
    return value
  }

  // Plain text / markdown / everything else.
  return buffer.toString("utf-8")
}

// OCR / transcribe a photo of notes using a vision model.
export async function extractFromImage(dataUrl: string): Promise<string> {
  const { text } = await generateText({
    model: MODELS.vision,
    messages: [
      {
        role: "user",
        content: [
          {
            type: "text",
            text: "Transcribe ALL text from this image of study notes. Preserve structure: headings, bullet points, numbering, and any diagrams described in words. Output clean plain text/markdown only — no commentary.",
          },
          { type: "image", image: new URL(dataUrl) },
        ],
      },
    ],
  })
  return text
}
