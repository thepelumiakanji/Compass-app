import {
  pgTable,
  text,
  timestamp,
  boolean,
  integer,
  jsonb,
  vector,
  index,
} from "drizzle-orm/pg-core"

// ---------------------------------------------------------------------------
// Better Auth tables (do not rename columns)
// ---------------------------------------------------------------------------
export const user = pgTable("user", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  emailVerified: boolean("emailVerified").notNull().default(false),
  image: text("image"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const session = pgTable("session", {
  id: text("id").primaryKey(),
  expiresAt: timestamp("expiresAt").notNull(),
  token: text("token").notNull().unique(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
  ipAddress: text("ipAddress"),
  userAgent: text("userAgent"),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
})

export const account = pgTable("account", {
  id: text("id").primaryKey(),
  accountId: text("accountId").notNull(),
  providerId: text("providerId").notNull(),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
  accessToken: text("accessToken"),
  refreshToken: text("refreshToken"),
  idToken: text("idToken"),
  accessTokenExpiresAt: timestamp("accessTokenExpiresAt"),
  refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt"),
  scope: text("scope"),
  password: text("password"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const verification = pgTable("verification", {
  id: text("id").primaryKey(),
  identifier: text("identifier").notNull(),
  value: text("value").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

// ---------------------------------------------------------------------------
// App tables
// ---------------------------------------------------------------------------

// A source: pasted text, an uploaded file, or a photo of notes.
export const documents = pgTable("documents", {
  id: text("id").primaryKey(),
  userId: text("userId").notNull(),
  title: text("title").notNull(),
  subject: text("subject"),
  sourceType: text("sourceType").notNull(), // "text" | "file" | "image"
  fileUrl: text("fileUrl"),
  fileType: text("fileType"),
  content: text("content").notNull(),
  status: text("status").notNull().default("ready"), // "processing" | "ready" | "error"
  createdAt: timestamp("createdAt").notNull().defaultNow(),
})

// Chunked + embedded text for retrieval (RAG).
export const chunks = pgTable(
  "chunks",
  {
    id: text("id").primaryKey(),
    userId: text("userId").notNull(),
    documentId: text("documentId").notNull(),
    content: text("content").notNull(),
    embedding: vector("embedding", { dimensions: 1536 }),
    createdAt: timestamp("createdAt").notNull().defaultNow(),
  },
  (t) => ({
    embeddingIdx: index("chunks_embedding_idx").using(
      "hnsw",
      t.embedding.op("vector_cosine_ops"),
    ),
  }),
)

// Generated study material derived from a document.
export const artifacts = pgTable("artifacts", {
  id: text("id").primaryKey(),
  userId: text("userId").notNull(),
  documentId: text("documentId"),
  kind: text("kind").notNull(), // "summary" | "flashcards" | "quiz" | "feynman" | "cornell" | "breakdown"
  title: text("title").notNull(),
  content: jsonb("content").notNull(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
})

export const chats = pgTable("chats", {
  id: text("id").primaryKey(),
  userId: text("userId").notNull(),
  title: text("title").notNull(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
})

export const messages = pgTable("messages", {
  id: text("id").primaryKey(),
  userId: text("userId").notNull(),
  chatId: text("chatId").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  citations: jsonb("citations"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
})

export const plans = pgTable("plans", {
  id: text("id").primaryKey(),
  userId: text("userId").notNull(),
  title: text("title").notNull(),
  goal: text("goal"),
  examDate: timestamp("examDate"),
  hoursPerDay: integer("hoursPerDay"),
  struggles: text("struggles"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
})

export const planTasks = pgTable("plan_tasks", {
  id: text("id").primaryKey(),
  userId: text("userId").notNull(),
  planId: text("planId").notNull(),
  dayIndex: integer("dayIndex").notNull(),
  dateLabel: text("dateLabel"),
  title: text("title").notNull(),
  description: text("description"),
  technique: text("technique"),
  durationMinutes: integer("durationMinutes"),
  done: boolean("done").notNull().default(false),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
})
